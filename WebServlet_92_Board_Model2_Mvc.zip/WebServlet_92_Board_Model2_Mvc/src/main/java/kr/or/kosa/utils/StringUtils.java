package kr.or.kosa.utils;

public class StringUtils {
   public static String titleSubString(String title) {
	   return title.substring(0, 10);
   }
}
